/*
 * fifo.c
 *
 *  Created on: 2018��4��7��
 *      Author: Administrator
 */
#include "fifo.h"

void fifo_init(fifo_t *fifo, void* base,uint32_t max_member_number, uint32_t menber_size) {
    fifo->base = (uint8_t*) base;
    fifo->size = max_member_number;
    fifo->member_size = menber_size;
    fifo->front = 0;
    fifo->rear = 0;
    fifo->is_empty = 1;
}

/*!
 * \brief   ��ȡfifoβָ��
 * \param   fifo    Ҫ������fifo
 */
status_t fifo_get_rear_pointer(fifo_t *fifo, void **rear_pointer) {
    if (fifo->rear == fifo->front       /* ����ͷβ��һ��,Ҫô�ǿ�,Ҫô����. */
            && fifo->is_empty == 0){    /* ������в��ǿ�. */
        *rear_pointer = NULL;           /* ���ܻ�ȡͷָ��; */
        return STATUS_ERROR;
    } else {                            /* ������Ի�ȡ. */
        *rear_pointer = fifo->base      /* fifo�ڴ��׵�ַ */
                + (fifo->member_size * fifo->rear);   /* +ƫ����. */
        return STATUS_SUCCESS;
    }
}

void fifo_append(fifo_t *fifo) {
    uint32_t rear_temp = fifo->rear;
    if ((++rear_temp) == fifo->size) {
        rear_temp = 0;
    }
    fifo->is_empty = 0;
    fifo->rear = rear_temp;
}

status_t fifo_get_front_data(fifo_t *fifo, void **data_pointer) {
    if (fifo->is_empty == 1) {
        return STATUS_ERROR;
    } else {
        *data_pointer = fifo->base
                + (fifo->member_size * fifo->front);
        return STATUS_SUCCESS;
    }
}
void fifo_release(fifo_t *fifo) {
    uint32_t front_temp = fifo->front;
    if ((++front_temp) == fifo->size) {
        front_temp = 0;
    }
    if (fifo->rear == front_temp) {
        fifo->is_empty = 1;
    }
    fifo->front = front_temp;
}

uint32_t fifo_get_element_count(fifo_t *fifo) {
//    uint32_t count = (fifo->size + fifo->rear - fifo->front) % fifo->size;
//    if (count == 0) {
//        if (fifo->is_empty == 1) {
//            return 0;
//        } else {
//            return fifo->size;
//        }
//    } else {
//        return count;
//    }
    if (fifo->front < fifo->rear) {
        return fifo->rear - fifo->front;
    } else if (fifo->front == fifo->rear) {
        if (fifo->is_empty == 1) {
            return 0;
        } else {
            return fifo->size;
        }
    } else {
        return fifo->size + fifo->rear - fifo->front;
    }
}

uint32_t fifo_get_size(fifo_t *fifo) {
    return fifo->size;
}

uint32_t fifo_get_memory_size(fifo_t *fifo) {
    return fifo->size * fifo->member_size;
}
