/*
 * flexcan.c
 *
 *  Created on: 2018��4��8��
 *      Author: Administrator
 */
#include "mflexcan.h"

flexcan_msgbuff_t can_receive_buff;
uint8_t           lpuart_receive_buff[8];


flexcan_data_info_t rx_info = {
        .data_length = 8,
        .enable_brs = 1,
        .fd_enable = 0,
        .fd_padding = 0,
        .is_remote = 0,
        .msg_id_type = FLEXCAN_MSG_ID_STD
};

flexcan_data_info_t tx_info = {
        .data_length = 8,
        .enable_brs = 1,
        .fd_enable = 0,
        .fd_padding = 0,
        .is_remote = 0,
        .msg_id_type = FLEXCAN_MSG_ID_STD
};

fifo_t flexcan_rx_fifo;
can_rx_element_type_t flexcan_rx_base[FLEXCAN_RX_FIFO_SIZE];


void flexcan_callback_update(uint8_t instance, flexcan_event_type_t eventType,
        struct FlexCANState * state){
    if (eventType == FLEXCAN_EVENT_RX_COMPLETE){
        can_rx_element_type_t *fifo_rear;
        uint8_t i = 0;
        for (i=0; i<can_receive_buff.dataLen; i++) {
            if (fifo_get_rear_pointer(&flexcan_rx_fifo, (void**)&fifo_rear) == STATUS_SUCCESS) {
                *fifo_rear = can_receive_buff.data[i];
                fifo_append(&flexcan_rx_fifo);
            }
        }
        FLEXCAN_DRV_Receive(0, RECEIVE_STD_MB, &can_receive_buff);
        FLEXCAN_DRV_Receive(0, RECEIVE_EXT_MB, &can_receive_buff);
    }
}


void flexcan_init(void) {
    fifo_init(&flexcan_rx_fifo,                                         /* can����fifo; */
            flexcan_rx_base,                                            /* can����fifo�ڴ�ռ�; */
            sizeof(flexcan_rx_base)/sizeof(can_rx_element_type_t),    /* can����fifoԪ������,���ڴ��С; */
            sizeof(can_rx_element_type_t));                           /* can���������������ʹ�С. */

    FLEXCAN_DRV_Init(0, &canCom0_State, &canCom0_InitConfig);

    FLEXCAN_DRV_SetRxMbGlobalMask(0, FLEXCAN_MSG_ID_EXT, RXMB_GLOBALMASK);

    FLEXCAN_DRV_ConfigRxMb(0, RECEIVE_STD_MB, &rx_info, RXID_UPDATE);
    FLEXCAN_DRV_InstallEventCallback(0, flexcan_callback_update, NULL);
    FLEXCAN_DRV_Receive(0, RECEIVE_STD_MB, &can_receive_buff);

    rx_info.msg_id_type = FLEXCAN_MSG_ID_EXT;
    FLEXCAN_DRV_ConfigRxMb(0, RECEIVE_EXT_MB, &rx_info, RXID_UPDATE);
    FLEXCAN_DRV_Receive(0, RECEIVE_EXT_MB, &can_receive_buff);

}


/*!
 * \brief       ��ȡcan0ʱ��Ƶ��
 * \param[out]  flexcanSourceClock  ʱ��Ƶ��
 */
void flexcan_get_source_clock(uint32_t *flexcanSourceClock) {
    if (canCom0_InitConfig.pe_clock == FLEXCAN_CLK_SOURCE_SYS){
        CLOCK_SYS_GetFreq(CORE_CLOCK, flexcanSourceClock);
    } else {
        uint32_t i = (SCG->SOSCDIV & SCG_SOSCDIV_SOSCDIV2_MASK) >> SCG_SOSCDIV_SOSCDIV2_SHIFT;
        CLOCK_SYS_GetFreq(SOSC_CLOCK, flexcanSourceClock);
        for (i=i-1; i>0; i--) {
            *flexcanSourceClock >>= 1;
        }
    }
}

