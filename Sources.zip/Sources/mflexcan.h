/*
 * flexcan.h
 *
 *  Created on: 2018��4��8��
 *      Author: Administrator
 */

#ifndef MFLEXCAN_H_
#define MFLEXCAN_H_

#include "S32K144.h"
#include "clockMan1.h"
#include "canCom0.h"
#include "pin_mux.h"
#include "dmaController1.h"
#include "osif.h"
#include "mlpuart.h"
#include "fifo.h"

#define RECEIVE_STD_MB  8
#define RECEIVE_EXT_MB  9
#define TRANSMIT_STD_MB 10
#define TRANSMIT_EXT_MB 11

#define RXMB_GLOBALMASK 0X7FFFFFFF
#define RXID_UPDATE     0x00000001

#define FLEXCAN_RX_FIFO_SIZE    (8*1024)
typedef uint8_t can_rx_element_type_t;


extern flexcan_msgbuff_t can_receive_buff;
extern uint8_t           lpuart_receive_buff[];
extern flexcan_data_info_t rx_info;
extern flexcan_data_info_t tx_info;

extern fifo_t flexcan_rx_fifo;

void flexcan_callback_update(uint8_t instance, flexcan_event_type_t eventType,
        struct FlexCANState * state);

void flexcan_init(void);

void flexcan_get_source_clock(uint32_t *flexcanSourceClock);



#endif /* MFLEXCAN_H_ */
