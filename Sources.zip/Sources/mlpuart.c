/*
 * lpuart.c
 *
 *  Created on: 2018��4��8��
 *      Author: Administrator
 */
#include "mlpuart.h"

//����1�жϷ������
//ע��,��ȡUSARTx->SR�ܱ���Ī������Ĵ���
#define USART_REC_LEN 100
uint8_t USART_RX_BUF[USART_REC_LEN];     //���ջ���,���USART_REC_LEN���ֽ�.
//����״̬
//bit15��    ������ɱ�־
//bit14��    ���յ�0x0d
//bit13~0��  ���յ�����Ч�ֽ���Ŀ
uint16_t USART_RX_STA=0;       //����״̬���


fifo_t lpuart_rx_fifo;
lpuart_rx_frame_t lpuart_rx_base[1024];
uint8_t lpuart_rx_len = 0;


void lpuart_RX_callback_update(uint32_t instance, void * lpuartState) {
    LPIT_HAL_StopTimerChannels(LPIT0, 0x01U);
    while ((LPUART0->FIFO & LPUART_FIFO_RXEMPT_MASK) == 0) {
        lpuart_rx_frame_t *frame;
        if (fifo_get_rear_pointer(&lpuart_rx_fifo, (void**)&frame) != STATUS_SUCCESS) {
            GPIO_HAL_ClearPins(PTC, 1<<11);
            return;
        }

        frame->data[lpuart_rx_len] = (uint8_t)LPUART0->DATA;
//        LPUART0->DATA = frame->data[lpuart_rx_len];
        lpuart_rx_len++;
        if (lpuart_rx_len == 8) {
            lpuart_rx_len = 0;
            frame->descriptor = 0x08;
            fifo_append(&lpuart_rx_fifo);
        } else {
            LPIT0->TMR[0].TVAL = lpit0_ChnConfig0.period;
            LPIT_HAL_StartTimerChannels(LPIT0, 0x01U);
        }
    }
}

/**
 * \brief   ���ڳ�ʼ������
 * \param   INST_LPUART0        ���ڱ��
 *          lpuart0_State       ���ڱ��洮��״̬�Ľṹ��
 *          lpuart0_user_config ����������Ϣ
 * \note    �ú�����򿪴��ڽ����ж�
 */
void init_lpuart(void) {
    fifo_init(&lpuart_rx_fifo, lpuart_rx_base, 1024, sizeof(lpuart_rx_frame_t));
    LPUART_DRV_Init(INST_LPUART0, &lpuart0_State, &lpuart0_InitConfig0);
    LPUART_DRV_InstallRxCallback(INST_LPUART0, lpuart_RX_callback_update, NULL);
    LPUART_DRV_ReceiveData(INST_LPUART0, lpuart_receive_buff, 8);
}


void lpuart_init_use_FIFO(void) {
    LPIT_DRV_Init(INST_LPIT0, &lpit0_InitConfig);
    LPIT_DRV_InitChannel(INST_LPIT0, 0, &lpit0_ChnConfig0);
    init_lpuart();
    LPUART0->CTRL &= ~LPUART_CTRL_TE_MASK;
    LPUART0->CTRL &= ~LPUART_CTRL_RE_MASK;
    LPUART0->FIFO |= LPUART_FIFO_RXFE(1);
    LPUART0->FIFO |= LPUART_FIFO_TXFE(1);
    LPUART0->CTRL |= LPUART_CTRL_TE_MASK;
    LPUART0->CTRL |= LPUART_CTRL_RE_MASK;
}

void LPUART0_transmit_char(char send) {    /* Function to Transmit single Char */
  while((LPUART0->STAT & LPUART_STAT_TDRE_MASK) == 0);
                                   /* Wait for transmit buffer to be empty */
  LPUART0->DATA=send;              /* Send data */

}

void LPUART0_transmit_string(char *data_string)  {  /* Function to Transmit whole string */
  uint32_t i=0;
  while(data_string[i] != '\0')  {           /* Send chars one at a time */
    LPUART0_transmit_char(data_string[i]);
    i++;
  }
}

char LPUART0_receive_char(void) {    /* Function to Receive single Char */
  char recieve;
  while((LPUART0->STAT & LPUART_STAT_RDRF_MASK)>>LPUART_STAT_RDRF_SHIFT==0);
                                     /* Wait for received buffer to be full */
  recieve= LPUART0->DATA;            /* Read received data*/
  return recieve;
}

void LPUART0_recieve_and_echo_char(void)  {  /* Function to echo received char back */

  char send = LPUART0_receive_char();        /* Receive Char */
  LPUART0_transmit_char(send);
  LPUART0_transmit_char('\n');               /* New line */
  LPUART0_transmit_char('\r');               /* Return */
}

uint8_t LPUART_transmit_number(LPUART_Type *LPUARTx, int32_t number) {
    uint8_t bit_of_number[10] = {0};
    uint8_t len, i;
    if (number < 0) {
        while((LPUARTx->STAT & LPUART_STAT_TDRE_MASK)>>LPUART_STAT_TDRE_SHIFT==0);
    /* Wait for transmit buffer to be empty */
        LPUARTx->DATA = '-';
        number = -number;
    }
    for(len=0;len<10;len++) {
        bit_of_number[len] = number % 10;
        number /= 10;
        if (number == 0) {
            len++;
            break;
        }
    }
    for(i=len;i;i--) {
        while((LPUARTx->STAT & LPUART_STAT_TDRE_MASK)>>LPUART_STAT_TDRE_SHIFT==0);
    /* Wait for transmit buffer to be empty */
        LPUARTx->DATA = '0'+bit_of_number[i-1];
    }
    return len;
}

void LPIT0_Ch0_IRQHandler(){
    lpuart_rx_frame_t *frame;
    LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT0, 0x01U);
//    LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
//    lpuart_rx_frame_t *frame;
//    if (fifo_get_rear_pointer(&lpuart_rx_fifo, (void**)&frame) != STATUS_SUCCESS) {
//        GPIO_HAL_ClearPins(PTC, 1<<11);
//        return;
//    }


    LPUART0->DATA = '#';
    LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
    while ((LPUART0->FIFO & LPUART_FIFO_RXEMPT_MASK) == 0) {
        if (fifo_get_rear_pointer(&lpuart_rx_fifo, (void**)&frame) != STATUS_SUCCESS) {
            GPIO_HAL_ClearPins(PTC, 1<<11);
            return;
        }

        frame->data[lpuart_rx_len] = (uint8_t)LPUART0->DATA;
//        LPUART0->DATA = frame->data[lpuart_rx_len];
        lpuart_rx_len++;
    }
    frame->descriptor = lpuart_rx_len|0x80;
    lpuart_rx_len = 0;
    fifo_append(&lpuart_rx_fifo);
    LPUART0->DATA = '0' + (frame->descriptor & 0x7f);
    LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
    GPIO_HAL_SetPins(PTC, 1<<12);
    while ((LPUART0->STAT & LPUART_STAT_TDRE_MASK) == 0);
    LPUART0->DATA = 'e';
}
