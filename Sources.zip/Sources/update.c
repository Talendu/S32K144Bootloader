/*
 * update.c
 *
 *  Created on: 2018��4��13��
 *      Author: Administrator
 */
#include "update.h"

uint32_t package_size = 0;

static void update_by_lpuart(void);
static void update_by_can(void);

void update_wait(void) {
    while(1) {
        if (fifo_get_element_count(&lpuart_rx_fifo) != 0) {
            LPUART0_transmit_string("Update by lpuart!\r\n");
            update_by_lpuart();                 /* �����յ�����,ʹ�ô����������� */
            break;
        } else if (fifo_get_element_count(&flexcan_rx_fifo) != 0) {
            update_by_can();                    /* CAN�յ�����,ʹ��CAN�������� */
            break;
        } else if ((GPIO_HAL_ReadPins(PTE) & (1<<7)) == 0) {
            break;
        }
    }
}

void update_init(void) {
    CRC_DRV_Init(INST_CRC, &crc_InitConfig0);
    flash_pflash_init();
    flexcan_init();
    lpuart_init_use_FIFO();
    LPUART0_transmit_string("Start update!\r\n");
}

void update(void) {
//    uint32_t fail_addr;
//    uint32_t program_base = 11<<12;
//    uint32_t i;
//    uint8_t datas[8] = {0,1,2,3,4,5,6,7};
    update_init();
//    update_wait();

    flash_pflash_erase_and_verify_sector(11, 128-11);
    update_by_lpuart();

//    flash_pflash_erase_and_verify_sector(11, 2);
//    for (i=0; i<4096;) {
//        flash_write_PFLASH(program_base + i, 8, datas, &fail_addr);
//        i += 8;
//    }
    while(1) {
        OSIF_TimeDelay(250);
        GPIO_HAL_TogglePins(PTC, 1<<12);
    }
}

static void update_by_lpuart(void) {
    lpuart_rx_frame_t *frame;
    int i=0;
    uint32_t fail_addr;
    uint8_t start_sector = 11;
    uint32_t program_base = start_sector<<12;

//    LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
//    flash_pflash_erase_and_verify_sector(start_sector, 128-start_sector);
//    LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
    while (1) {
        if (fifo_get_front_data(&lpuart_rx_fifo, (void**)&frame) == STATUS_SUCCESS) {

//            LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
//            flash_write_PFLASH(program_base + package_size,
//                        8,//frame->descriptor,
//                        frame->data, &fail_addr);
//            LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
//            package_size += 8;
//            fifo_release(&lpuart_rx_fifo);
            if ((frame->descriptor & 0x80) != 0) {
                while ((LPUART0->STAT & LPUART_STAT_TDRE_MASK) == 0);
                LPUART0->DATA = 'x';
                frame->descriptor &= 0x7f;
                LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
                if (flash_write_PFLASH(program_base + package_size,
                        frame->descriptor,
                        frame->data, &fail_addr) != STATUS_SUCCESS) {
                    LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
                    LPUART0_transmit_string("Failure to program! \r\n");
                    return;
                }
                LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
                CRC_DRV_WriteData(INST_CRC, frame->data, frame->descriptor);
                package_size += frame->descriptor;
                fifo_release(&lpuart_rx_fifo);
                LPUART0_transmit_string("Program success!\r\n");
                LPUART0_transmit_string("CRC: ");
                LPUART_transmit_number(LPUART0, CRC_DRV_GetCrcResult(INST_CRC));
                LPUART0_transmit_string("\r\ndata length: ");
                LPUART_transmit_number(LPUART0, package_size);
                LPUART0_transmit_string("\r\n\r\n");
                return;
            } else {
                LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
                if (flash_write_PFLASH(program_base + package_size, 8,
                        frame->data, &fail_addr) != STATUS_SUCCESS) {
                    LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
                    LPUART0_transmit_string("Failure to program! \r\n");
                    return;
                }
                LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
                CRC_DRV_WriteData(INST_CRC, frame->data, 8);
                package_size += 8;
                fifo_release(&lpuart_rx_fifo);
//                if (package_size % 4096 == 0) {
//                    LPUART0->CTRL &= ~LPUART_CTRL_RIE_MASK;
////                    flash_pflash_erase_and_verify_sector(start_sector + package_size/4096, 1);
////                    LPUART0->CTRL |= LPUART_CTRL_RIE_MASK;
//                }
            }
//            for (i=0; i<(frame->descriptor&0x7f); i++) {
//                while ((LPUART0->STAT & LPUART_STAT_TDRE_MASK) == 0);
//                    LPUART0->DATA = frame->data[i];
//            }
//            fifo_release(&lpuart_rx_fifo);
        }
//
//        if (fifo_get_rear_pointer(&lpuart_rx_fifo, (void**)&frame) == STATUS_SUCCESS) {
//            int i = 0;
//            for (i=0; i<8; i++) {
//                frame->data[i] = i;
//            }
//            frame->descriptor = 8;
//            fifo_append(&lpuart_rx_fifo);
//        }
//
//        if (package_size > 4096) {
//            break;
//        }

    }
}

static void update_by_can(void) {

}
