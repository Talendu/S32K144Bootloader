/*
 * update.h
 *
 *  Created on: 2018��4��13��
 *      Author: Administrator
 */

#ifndef UPDATE_H_
#define UPDATE_H_

#include "crc.h"
#include "mlpuart.h"
#include "mflexcan.h"
#include "mflash.h"

void update(void);

#endif /* UPDATE_H_ */
